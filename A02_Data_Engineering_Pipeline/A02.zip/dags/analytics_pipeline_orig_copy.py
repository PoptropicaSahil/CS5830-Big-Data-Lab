import glob
import logging
import os
import sys
from datetime import datetime

import apache_beam as beam  # type: ignore
import geopandas as gpd  # type: ignore
import matplotlib.pyplot as plt  # type: ignore
import numpy as np  # type: ignore
import pandas as pd  # type: ignore
from shapely.geometry import Point  # type: ignore

from airflow import DAG
from airflow.models import Variable
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.sensors.filesystem import FileSensor

sys.path.append(os.path.expanduser("~/BDL/A02/"))

working_dir = os.path.expanduser("~/BDL/A02/")
os.makedirs(working_dir + "tmp", exist_ok=True)

# Now you can import the script and use its functions
# import script_name
# from pipeline_2_funcs import


def update_inputs(**kwargs):

    # context['ti'].xcom_push(key='archive_file_path', value="/final/data.zip")
    try:
        Variable.set("archive_file_path", kwargs["dag_run"].conf["archive_file_path"])
        Variable.set("required_cols", kwargs["dag_run"].conf["required_cols"])
        logging.info(
            "input fields archive_file_path and required_cols read successfully"
        )
    except KeyError:
        logging.error("""Entered archive_file_path or required_cols is empty, ensure you pass
                                config args as --conf '{"archive_file_path": "<archive_file_path>", "required_cols": ["col1", "col2"]}'
                                """)
        exit()
    return


def process_df_hourly_data_array(**kwargs):
    status = kwargs["ti"].xcom_pull(key="return_value", task_ids="validate_and_unzip")
    if status == "error":
        logging.error("failed to unzip the data")
        exit()

    logging.info("successfully unzipped the data")
    # Use glob to find all CSV files in the directory
    csv_files = glob.glob(f"{working_dir}/tmp/*.csv")

    # Display the list of CSV file paths
    logging.info(f"csv_files read from glob are {csv_files} ")

    required_cols = Variable.get("required_cols", default_var=["ELEVATION"])
    logging.info(f"required_cols input by user is {required_cols}")

    # Convert the string input to a list
    required_cols = eval(required_cols)

    def read_csv(file_name):
        # if cols_to_read not in the dataframe
        cols_to_read = required_cols + ["LATITUDE", "LONGITUDE"]

        cols_in_df = pd.read_csv(csv_files[0]).columns.tolist()
        cols_to_read_not_in_df = [i for i in cols_to_read if i not in cols_in_df]

        if cols_to_read_not_in_df:
            logging.error(
                f"Specified columns not found in CSV file: {cols_to_read_not_in_df}"
            )
            exit()
        else:
            logging.info("All specified columns found in CSV file")

        return pd.read_csv(file_name, usecols=cols_to_read)

    def make_tuples(df):
        # Initialize an empty list to store the aggregated hourly data
        aggregated_hourly_data = []

        # Iterate over groups
        for (lat, lon), group in df.groupby(["LATITUDE", "LONGITUDE"]):
            # Extract required hourly data for each group
            hourly_data = group[required_cols].values.tolist()
            aggregated_hourly_data.extend(hourly_data)

        # Create a tuple containing latitude, longitude, and aggregated hourly data
        result = (
            df["LATITUDE"].iloc[0],
            df["LONGITUDE"].iloc[0],
            aggregated_hourly_data,
        )
        return result

    output_path = working_dir + "/tmp/" + "values_arrays.txt"
    with beam.Pipeline() as p:
        csv_data = (
            p | beam.Create(csv_files) | beam.Map(read_csv) | beam.Map(make_tuples)
        )
        csv_data | beam.io.WriteToText(
            output_path,
            num_shards=1,
        )

    return


def process_df_monthly_avg(**kwargs):
    status = kwargs["ti"].xcom_pull(key="return_value", task_ids="validate_and_unzip")

    if status == "error":
        logging.error("failed to unzip the data")
        exit()

    logging.info("successfully unzipped the data")

    csv_files = glob.glob(f"{working_dir}/tmp/*.csv")

    # Display the list of CSV file paths
    logging.info(f"csv_files read from glob are {csv_files} ")

    required_cols = Variable.get("required_cols", default_var=["HourlyWindSpeed"])
    logging.info(f"required_cols input by user is {required_cols}")

    # Convert the string input to a list
    required_cols = eval(required_cols)

    def read_csv(file_name):
        # if cols_to_read not in the dataframe
        cols_to_read = required_cols + ["DATE", "LATITUDE", "LONGITUDE"]
        cols_in_df = pd.read_csv(csv_files[0]).columns.tolist()
        cols_to_read_not_in_df = [i for i in cols_to_read if i not in cols_in_df]
        if cols_to_read_not_in_df:
            logging.error(
                f"Specified columns not found in CSV file: {cols_to_read_not_in_df}"
            )
            exit()
        else:
            logging.info("All specified columns found in CSV file")
        return pd.read_csv(file_name, usecols=cols_to_read)

    def monthly_avg(df):
        lat = df["LATITUDE"].iloc[0]
        lon = df["LONGITUDE"].iloc[0]

        data = df.values.tolist()
        monthly_avg = []

        required_cols_idx = [df.columns.get_loc(c) for c in required_cols]

        for col in required_cols_idx:
            col_monthly_avg = []
            for month in range(1, 13):
                month_data = [x[col] for x in data if int(x[0].split("-")[1]) == month]
                month_data = np.array(
                    [
                        float(x) if str(x).replace(".", "", 1).isdigit() else np.nan
                        for x in month_data
                    ],
                    dtype=np.float32,
                )
                col_avg = np.nanmean(month_data)
                col_monthly_avg.append(col_avg)
            monthly_avg.append(col_monthly_avg)
            logging.info(f"Calculating monthly_avg as {monthly_avg}")

        # Convert it to required format
        monthly_avg = [list(x) for x in zip(*monthly_avg)]

        logging.info(f"RETURNING {(lat, lon, monthly_avg)}")
        return (lat, lon, monthly_avg)

    output_path = working_dir + "/tmp" + "/values_averages.txt"

    with beam.Pipeline() as p:
        csv_data = (
            p | beam.Create(csv_files) | beam.Map(read_csv) | beam.Map(monthly_avg)
        )

        csv_data | beam.io.WriteToText(
            output_path,
            num_shards=1,
        )
    return


def make_heatmaps(**kwargs):
    # open the output from previous file

    reading_path = working_dir + "/tmp" + "/values_averages.txt" + "-00000-of-00001"
    with open(reading_path, "r") as file:
        content = file.readlines()

    logging.info(f"content is \n{content}")

    # Convert nan to python-understandable None
    content = [i.replace("nan", "None") for i in content]

    logging.info("read the tuple from the previous python operator")
    data = [eval(line.strip()) for line in content]

    def process_data(data):
        # Extract latitude, longitude, and monthly averages for each field
        latitudes = [entry[0] for entry in data]
        longitudes = [entry[1] for entry in data]
        monthly_averages = [entry[2] for entry in data]

        logging.info("Extracted coordinates and data values from the tuple")
        return latitudes, longitudes, monthly_averages

    def generate_heatmap(latitudes, longitudes, monthly_averages, required_cols):
        # Create a GeoDataFrame with latitude, longitude, and field averages
        geometry = [Point(lon, lat) for lon, lat in zip(longitudes, latitudes)]

        df = pd.DataFrame(
            {
                "Latitude": latitudes,
                "Longitude": longitudes,
                "MonthlyAverages": monthly_averages,
            }
        )
        print(f"pandas df = \n{df}")
        crs = {"init": "epsg:4326"}

        for i, field_name in enumerate(required_cols):
            df[field_name] = [monthly_avg[0][i] for monthly_avg in monthly_averages]

        # print(f"df with fields is \n{df}")

        # print(f'df iloc 1 is {df.iloc[1]}')

        gdf = gpd.GeoDataFrame(df, crs=crs, geometry=geometry)
        # print(f"geopandas df is \n{gdf}")

        # Plot heatmaps for each field
        for i, field_name in enumerate(required_cols):
            world = gpd.read_file(gpd.datasets.get_path("naturalearth_lowres"))
            fig, ax = plt.subplots(figsize=(12, 8))
            world.plot(ax=ax, color="white", edgecolor="gray")

            # plot the values only if the field is not null
            if gdf[field_name].notnull().any():
                gdf.plot(
                    column=field_name, cmap="coolwarm", linewidth=6, ax=ax, legend=True
                )
                ax.set_title(
                    f"Heatmap of {field_name}\nfor given {df.shape[0]} stations",
                    fontdict={"fontsize": "18", "fontweight": "3"},
                )
            else:
                ax.set_title(
                    f"Heatmap of {field_name} for given {df.shape[0]} stations.\nNo data available for this field.",
                    fontdict={"fontsize": "15", "fontweight": "3"},
                )

            ax.autoscale()
            ax.axis("off")
            fig.tight_layout()

            os.makedirs(working_dir + "/output_heatmaps", exist_ok=True)
            plt.savefig(
                working_dir + "/output_heatmaps" + f"/heatmap_geo_{field_name}.png"
            )

    def run_pipeline(data):
        latitudes, longitudes, monthly_averages = process_data(data)
        required_cols = Variable.get("required_cols", default_var=["HourlyWindSpeed"])
        required_cols = eval(required_cols)
        logging.info("Starting to generate the heatmaps")
        generate_heatmap(latitudes, longitudes, monthly_averages, required_cols)

    # Run pipeline
    with beam.Pipeline(runner="DirectRunner") as pipeline:
        p = (
            pipeline
            | "Create data" >> beam.Create([data])
            | "Run pipeline" >> beam.Map(run_pipeline)
        )

    return


# create dag
with DAG(
    dag_id="analytics_new",
    schedule="@daily",
    start_date=datetime(year=2022, month=2, day=19),
    end_date=datetime(year=2025, month=3, day=18),
    catchup=False,
    tags=["test"],
) as dag:
    
    task_set_path = PythonOperator(
        task_id="set_path", python_callable=update_inputs, dag=dag
    )

    # Create variable
    filepath = Variable.get("archive_file_path", default_var="/ARCHIVE/data_files.zip")
    logging.info(f"filepath later is {filepath}")

    # CHECK if the file exists
    if os.path.exists(filepath):
        logging.warning(f"VALIDATED The file at {filepath} exists.")
    else:
        error_msg = f"The file at {filepath} does not exist."
        logging.error(error_msg)
        # exit()

    task_wait_for_archive = FileSensor(
        task_id="wait_for_archive",
        filepath=working_dir + filepath,
        poke_interval=10,
        timeout=5,
        dag=dag,
    )

    task_validate_and_unzip = BashOperator(
        task_id="validate_and_unzip",
        bash_command=f"""
        if [ -f {working_dir + filepath} ]; then
            unzip -o {working_dir + filepath} -d {working_dir}/tmp/
            echo "success"
        else 
            echo "error"
        fi 
        """,
        dag=dag,
    )

    task_process_df_hourly = PythonOperator(
        task_id="process_df_hourly_data_array",
        python_callable=process_df_hourly_data_array,
    )
    task_process_df_monthly_avg = PythonOperator(
        task_id="process_df_monthly_avg", python_callable=process_df_monthly_avg
    )
    task_make_heatmaps = PythonOperator(
        task_id="make_heatmaps", python_callable=make_heatmaps
    )

    task_delete_tmp_dir = BashOperator(
        task_id="delete_tmp_directory",
        bash_command=f"""rm -r {working_dir}/tmp""",
        dag=dag,
    )

    # define dependencies
    (
        task_set_path
        >> task_wait_for_archive
        >> task_validate_and_unzip
        >> task_process_df_hourly
        >> task_process_df_monthly_avg
        >> task_make_heatmaps
        >> task_delete_tmp_dir
    )  # type: ignore
