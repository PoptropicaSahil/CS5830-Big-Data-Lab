import os
import sys
from datetime import datetime

from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator

# sys.path.append('~/BDL/A02/')
sys.path.append(os.path.expanduser("~/BDL/A02/"))

from utils.pipeline_1_funcs import (
    fetch_individual_files,
    place_archive_to_location,
    select_random_files_from_fetched_html,
    zip_files_into_archive,
)

working_dir = os.path.expanduser("~/BDL/A02/")


# create dag
with DAG(
    dag_id="datafetch_sahil",
    schedule="@daily",
    start_date=datetime(year=2022, month=2, day=19),
    end_date=datetime(year=2025, month=3, day=18),
    catchup=False,
    tags=["test"],
) as dag:

    # fetch page contents using wget
    task_fetch_page = BashOperator(
        task_id="fetch_page",
        bash_command="""wget -O ~/BDL/A02/tmp/datasets_new.html 'https://www.ncei.noaa.gov/data/local-climatological-data/access/{{dag_run.conf["year"] if dag_run else ""}}'
        """,
    )

    # select files from fetched HTML
    task_select_files = PythonOperator(
        task_id="select_random_files_from_fetched_html",
        python_callable=select_random_files_from_fetched_html,
        provide_context=True,
    )

    # download the selected files
    task_fetch_csv_files = PythonOperator(
        task_id="fetch_individual_files",
        python_callable=fetch_individual_files,
        provide_context=True,
    )

    # create zip archive
    task_zip_csv_files = PythonOperator(
        task_id="zip_files_into_archive",
        python_callable=zip_files_into_archive,
        provide_context=True,
    )

    # place zip to a location
    task_place_archive = PythonOperator(
        task_id="place_archive_to_location",
        python_callable=place_archive_to_location,
        provide_context=True,
    )

    # create task to delete the tmp dir
    task_delete_tmp_dir = BashOperator(
        task_id="delete_tmp_directory",
        bash_command=f"""rm -r {working_dir}/tmp""",
        dag=dag,
    )

    # define dependencies
    (
        task_fetch_page
        >> task_select_files
        >> task_fetch_csv_files
        >> task_zip_csv_files
        >> task_place_archive
        >> task_delete_tmp_dir
    ) # type:ignore
