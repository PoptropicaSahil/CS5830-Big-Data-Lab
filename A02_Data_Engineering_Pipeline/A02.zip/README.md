# Creating Pipelines in Apache Beam!

It is recommened to create a virtual environment using venv before proceeding. \
To install the required packages, use the following command `pip install -r requirements.txt`


**Notes**
* All development was done on WSL2 on Windows 10
* Run all terminal commands given below using the Bash terminal, preferably being in the `~/BDL/A02` directory. **This is the working directory for all code**


## 📐 Setting up Airflow 📐
* Setup airflow `export AIRFLOW_HOME=~/airflow`
* Ensure that the `dags_folder` is set correctly in the airflow config file `/root/airflow/airflow.cfg` by setting `dags_folder = /root/BDL/A02/dags`
* Open a terminal to start the webserver `airflow webserver -p 8080`
* Open another terminal to run the scheduler `airflow scheduler`

## ✅ Running the code ✅

### Datafetch pipeline (**datafetch_sahil**)
<img src="readme_figs/datafetch.png" alt="drawing" width="2000"/>

*Arguments information:*

| **Argument**  | **Description**                                                  | **Type** | **Example** |
|---------------|------------------------------------------------------------------|----------|-------------|
| "year"        | The year (between 1901 and 2024) of which data has to be fetched | int      | 2019        |
| "num_samples" | Number of files to be analysed                                   | int      | 5           |
| "archive_dir" | Directory path to store the zip archive                          | str      | "ARCHIVE"   |

* Triggering the pipeline
```
airflow dags trigger 'datafetch_sahil' --conf '{"year":2019, "num_samples":5, "archive_dir": "ARCHIVE"}'
```

### Analytics pipeline (**analytics_sahilll**)
<img src="readme_figs/analytics.png" alt="drawing" width="2000"/>
*Arguments information:*

| **Argument**        | **Description**                                  | **Type** | **Example**                                                               |
|---------------------|--------------------------------------------------|----------|---------------------------------------------------------------------------|
| "archive_file_path" | Path of the zip archive after datafetch pipeline | str      | "ARCHIVE/data_files.zip"                                                  |
| "required_cols"     | List of columns to be analysed                   | list     | ["HourlyWindSpeed", "HourlyDryBulbTemperature", "HourlyRelativeHumidity"] |



* Triggering the pipeline
```
airflow dags trigger 'analytics_sahilll'  --conf '{"archive_file_path": "ARCHIVE/data_files.zip", "required_cols": ["HourlyWindSpeed", "HourlyDryBulbTemperature", "HourlyRelativeHumidity"]}'
```

## ➕ Additional information ➕
- Plots will be stored in the `output_heatmaps` directory
- Validation checks are done within folders. Mostly as *WARNING* and *ERROR* log messages
- All dags are stored in the `dags` directory, and their corresponding components are in the `utils` directory
- The code has been run on *my 8GB CPU machine*
- If the pipeline does not trigger, it is advised to run `airflow dags list-import-errors` (which should ideally not lists our pipelines), then trigger the pipelines again
- Additionally, sometimes you may want to kill airflow processes and then trigger the pipelines afresh with `ps -ef | grep air` and `pkill -f airflow`
- It may be required to install the unzip command externally by `sudo apt-get install unzip`
- I have installed airflow using the following command
```
pip install "apache-airflow[celery]==2.8.1" --constraint "https://raw.githubusercontent.com/apache/airflow/constraints-2.8.1/constraints-3.8.txt"
```


## 😁 Code-cleanliness! 😁
- Type hints from the `typing` module are leveraged
- All code is pep-8 style formatted using `ruff`, `isort` and `black` as pre-commit hooks


## 📕 References 📕
- Apache Airflow Documentation


## 🚗 Directory Structure 🚗
* Directory structure for the run is <br>
**root** <br>
├── **airflow** <br>
│   ├── logs/ <br>
│   ├── airflow.cfg <br>
│   ├── ... <br>
├── **BDL/A02** <br>
│   ├── dags <br>
│   ├──   ├── analytics_pipeline.py <br>
│   ├──   ├── datafetch_pipeline.py <br>
│   ├── utils <br>
│   ├──   ├── pipeline_1_funcs.py <br>
│   ├──   ├── pipeline_1_funcs.py <br>
│   └── **venv** <br>
│   ├── ... <br>
│   ├── README.md <br>
│   ├── requirements.txt <br>